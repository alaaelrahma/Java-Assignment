//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    // Q2
    public static void main(String[] args) {
        public static Integer max(ArrayList<Integer> list) {
            if (list == null || list.size() == 0) {
                return null;
            }

            Integer maxVal = list.get(0);
            for (Integer num : list) {
                if (num > maxVal) {
                    maxVal = num;
                }
            }

            return maxVal;
        }

        // q3

        import java.util.ArrayList;
import java.util.Collections;

        public static void sort(ArrayList<Integer> list) {
            if (list == null || list.size() == 0) {
                return;
            }

            Collections.sort(list);
        }



    }
}