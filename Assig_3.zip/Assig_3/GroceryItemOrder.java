public class GroceryItemOrder {
    private String name;
    private int quantity;
    private double pricePerUnit;

    // Constructor
    public GroceryItemOrder(String name, int quantity, double pricePerUnit) {
        this.name = name;
        this.quantity = quantity;
        this.pricePerUnit = pricePerUnit;
    }

    // Getter for the total cost of the item order
    public double getCost() {
        return quantity * pricePerUnit;
    }

    // Getters and setters for each field
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPricePerUnit() {
        return pricePerUnit;
    }

    public void setPricePerUnit(double pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
    }

    // toString method for easier display of item details
    @Override
    public String toString() {
        return quantity + " x " + name + " @ $" + pricePerUnit + " each";
    }

}
