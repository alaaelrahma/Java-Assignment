public class GroceryList {

    import java.util.ArrayList;

        private ArrayList<GroceryItemOrder> items;
        private static final int MAX_ITEMS = 10;  // Assume a maximum of 10 items allowed

        // Constructor
        public GroceryList() {
            items = new ArrayList<>();
        }

        // Adds a new item to the list if there's room
        public void add(GroceryItemOrder item) {
            if (items.size() < MAX_ITEMS) {
                items.add(item);
            } else {
                System.out.println("Cannot add more items. The list is full.");
            }
        }

        // Calculates the total cost of all items in the list
        public double getTotalCost() {
            double total = 0;
            for (GroceryItemOrder item : items) {
                total += item.getCost();
            }
            return total;
        }

        // toString method for easier display of list details
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder("Grocery List:\n");
            for (GroceryItemOrder item : items) {
                sb.append(item.toString()).append("\n");
            }
            sb.append("Total Cost: $").append(getTotalCost());
            return sb.toString();
        }
    }


